
def Download_file(url, save_name):
    import urllib.request

    response = urllib.request.urlopen(url)
    with open(save_name, 'wb') as file:
        file.write(response.read())


def DarkWolves_target_url(url):
  import urllib.request
  return urllib.request.urlopen(url)

def DarkWolves_target_url_content(url):
  return DarkWolves_target_url(url).read()

def Name_From_PathAddress(FilePath):
  LetterNumber = -1
  NameLetters = FilePath[LetterNumber]
  while FilePath[LetterNumber] != '/':
    LetterNumber -=1
    NameLetters = FilePath[LetterNumber] + NameLetters

  return NameLetters

def Name_From_PathAddress_Without(FilePath):
  LetterNumber = -1
  NameLetters = FilePath[LetterNumber]
  while FilePath[LetterNumber] != '/':
    LetterNumber -=1
    NameLetters = FilePath[LetterNumber] + NameLetters
    NameLetters = NameLetters.replace('/','')
  return NameLetters

def DarkWolves_Copyfile(file , Copy_to, Name):

  if Name is None:
    with open(Name_From_PathAddress_Without(file), 'wb') as f:
      f.write(file.read())


  else:

    with open(Name, 'wb') as f:
      f.write(file.read())


def DarkWolves_response_text(url):
  import urllib.request
  return urllib.request.urlopen(url).read().decode('utf-8')

def DarkWolves_response_json(url):
  import urllib.request
  return urllib.request.urlopen(url).read().decode('utf-8')

def DarkWolves_response_json_text(url):
  import urllib.request
  return urllib.request.urlopen(url).read().decode('utf-8')

def DarkWolves_response_json_text_text(url):
  import urllib.request
  return urllib.request.urlopen(url).read().decode('utf-8')

def Highest_Number_In_List(List):
  HighestNumber = 0
  for i in List:
    if i > HighestNumber:
      HighestNumber = i
  return HighestNumber

def Lowest_Number_In_List(List):
  LowestNumber = Highest_Number_In_List(List)
  for i in List:
    if i < LowestNumber:
      LowestNumber = i
  return LowestNumber

def Sort(List,mode):
  mode = mode.lower()
  if mode == 'high to low':
    return Higest_Number_to_Lowest_Number(List)
    
  elif mode == 'low to high':
    return Lowest_Number_to_Highest_Number(List)
  else:
    return List


def Higest_Number_to_Lowest_Number(List):
  Higest_Number_to_Lowest_Number = []
  while len(List) != 0:
    Higest_Number_to_Lowest_Number.append(Highest_Number_In_List(List))
    List.remove(Highest_Number_In_List(List))
  return Higest_Number_to_Lowest_Number

def Lowest_Number_to_Highest_Number(List):
  Lowest_Number_to_Highest_Number = []
  while len(List) != 0:
    Lowest_Number_to_Highest_Number.append(Lowest_Number_In_List(List))
    List.remove(Lowest_Number_In_List(List))
  return Lowest_Number_to_Highest_Number


def List_Duplicate_Remover(List , ListName):
  ListName = ListName.lower()
  if ListName == 'duplicates' or 'after_remove_duplicates':
    After_Remove_Duplicates = []
    Duplicates = []
    i = 0

    while i < len(List):
      if List[i] not in After_Remove_Duplicates:
        After_Remove_Duplicates.append(List[i])
      else:
        Duplicates.append(List[i])
      i += 1
    if ListName == 'duplicates':
      return Duplicates
    elif ListName == 'after_remove_duplicates':
      return  After_Remove_Duplicates
  else:
    return List

import socket

def upload_file_to_server(file_path, server_address, server_port):
    import socket
    # Open the file in binary mode
    with open(file_path, 'rb') as file:
        # Create a TCP socket
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        try:
            # Connect to the server
            client_socket.connect((server_address, server_port))

            # Read and send the file data in chunks
            while True:
                data = file.read(1024)  # Read 1KB at a time
                if not data:
                    break
                client_socket.sendall(data)

        finally:
            # Close the socket
            client_socket.close()