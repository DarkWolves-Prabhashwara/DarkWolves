from setuptools import setup ,find_packages

setup(
    name = 'DarkWolves',
    version='1.0',
    packages=find_packages(),
    description='This package were made by DarkWolves Group',
    url={'pypi.org':'https://pypi.org/user/DarkWolves/',
         'Github':'https://github.com/DarkWolves-Prabhashwara',
         'youtube.com':'https://www.youtube.com/channel/UCfxLG1GtImO9KcjoP6PKmXA',
         'ExpertOption':'https://eo.shortlify.com/970740005'
         },
    license='MIT',
    author_email='prabhashwarapay@gmail.com',
    author='Prabhashwara Ravihara',
    long_description= '''in the README.TXT file, and follow the these links!pypi.org':'https://pypi.org/user/DarkWolves/',
         'Github':'https://github.com/DarkWolves-Prabhashwara',
         'youtube.com':'https://www.youtube.com/channel/UCfxLG1GtImO9KcjoP6PKmXA',
         'ExpertOption':'https://eo.shortlify.com/970740005 , I Will tech you how to use this package in my youtube channel, And I hope you guys 
         will be able to use this package to do their job easily''',
    long_description_content_type = ' text, videos, documents, resourse links'
    
    )
